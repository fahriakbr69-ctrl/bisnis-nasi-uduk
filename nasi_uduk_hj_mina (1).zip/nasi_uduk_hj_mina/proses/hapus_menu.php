<?php
require_once __DIR__."/../auth.php"; wajib_admin();
include "../koneksi.php";

// Ambil ID secara aman
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // 1. Ambil nama file foto sebelum data dihapus dari database
    $query_foto = mysqli_query($conn, "SELECT foto FROM menu WHERE id=$id");
    $data_foto  = mysqli_fetch_assoc($query_foto);

    // 2. Hapus data dari database
    $hapus = mysqli_query($conn, "DELETE FROM menu WHERE id=$id");

    if ($hapus) {
        // 3. Jika berhasil dihapus di DB, hapus juga file gambar fisik di folder uploads
        if (!empty($data_foto['foto'])) {
            $file_path = "../uploads/" . $data_foto['foto'];
            if (file_exists($file_path)) {
                unlink($file_path); // Menghapus file gambar
            }
        }
    } else {
        // Jika gagal (misal karena terikat transaksi/foreign key)
        echo "<script>
                alert('Gagal menghapus menu! Menu mungkin sedang terikat dengan data pesanan/transaksi.');
                window.location.href='../menu.php';
              </script>";
        exit;
    }
}

header("Location: ../menu.php");
exit;
?>
<?php
define('BASE', '../');
include_once __DIR__."/../koneksi.php";
require_once __DIR__."/../auth.php"; // hanya untuk cek sesi admin, tidak memaksa login
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nasi Uduk Hj. Mina</title>
<link rel="stylesheet" href="<?= BASE ?>assets/user.css">
</head>
<body>
<nav>
    <b>Nasi Uduk Hj. Mina</b>
    <span>
        <a href="index.php">Menu</a>
        <a href="lacak.php">Lacak Pesanan</a>
        <?php if (!empty($_SESSION['admin'])): ?>
            <a href="<?= BASE ?>index.php">Dashboard Admin</a>
            <a href="<?= BASE ?>logout.php">Keluar</a>
        <?php else: ?>
            <a href="<?= BASE ?>login.php" style="opacity:.7">Login Admin</a>
        <?php endif; ?>
    </span>
</nav>
<main>

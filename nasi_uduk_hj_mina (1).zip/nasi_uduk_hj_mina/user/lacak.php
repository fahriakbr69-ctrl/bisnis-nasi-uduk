<?php
include "header.php";
$o = null;
if (isset($_GET['kode']) && $_GET['kode'] !== '') {
    $kode = mysqli_real_escape_string($conn, $_GET['kode']);
    $o = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pesanan WHERE kode='$kode'"));
}
?>
<h1>Lacak Pesanan</h1>
<div class="box">
    <form method="get">
        <label>Masukkan Kode Pesanan</label>
        <input name="kode" required placeholder="Contoh: ORD-260925123456" value="<?= htmlspecialchars($_GET['kode'] ?? '') ?>">
        <button>Cari</button>
    </form>
</div>
<?php if (isset($_GET['kode']) && $_GET['kode'] !== ''): ?>
    <?php if (!$o): ?>
    <div class="box err">Pesanan dengan kode tersebut tidak ditemukan.</div>
    <?php else:
        $detail = mysqli_query($conn, "SELECT d.*, m.nama_menu FROM pesanan_detail d JOIN menu m ON m.id=d.menu_id WHERE pesanan_id={$o['id']}");
    ?>
    <div class="box">
        <h3><?= htmlspecialchars($o['kode']) ?></h3>
        <p>Pemesan: <b><?= htmlspecialchars($o['nama_pemesan']) ?></b> &nbsp; Tanggal: <?= date('d/m/Y H:i', strtotime($o['tanggal'])) ?></p>
        <table>
            <tr><th>Menu<th>Qty<th>Subtotal</tr>
            <?php foreach ($detail as $x): ?>
            <tr><td><?= htmlspecialchars($x['nama_menu']) ?><td><?= $x['jumlah'] ?><td>Rp <?= number_format($x['jumlah'] * $x['harga'], 0, ',', '.') ?></tr>
            <?php endforeach; ?>
            <tr><th colspan=2>Total<th>Rp <?= number_format($o['total'], 0, ',', '.') ?></tr>
        </table>
        <p>Metode: <b><?= htmlspecialchars($o['metode']) ?></b> &nbsp; Pembayaran: <?= tag($o['status_bayar']) ?> &nbsp; Pesanan: <?= tag($o['status_pesanan']) ?></p>
        <?php if ($o['status_bayar'] != 'Lunas'): ?>
        <a class="btn" href="bayar.php?id=<?= $o['id'] ?>&kode=<?= urlencode($o['kode']) ?>">Lanjutkan Pembayaran</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>
</main>
</body>
</html>

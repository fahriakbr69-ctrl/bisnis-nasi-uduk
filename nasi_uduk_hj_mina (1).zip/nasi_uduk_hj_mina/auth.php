<?php
session_start();
define('BASE', rtrim(str_replace(str_replace('\\','/',$_SERVER['DOCUMENT_ROOT']),'',str_replace('\\','/',__DIR__)),'/').'/');

function wajib_admin(){
    if (empty($_SESSION['admin'])){
        header("Location: ".BASE."login.php");
        exit;
    }
}


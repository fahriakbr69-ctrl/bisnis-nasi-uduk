<?php
require_once __DIR__."/../auth.php"; wajib_admin();
// Gunakan ../ untuk keluar dari folder proses menuju folder utama
include "../koneksi.php";

$id = $_GET['id'] ?? '';
$query = mysqli_query($conn, "SELECT * FROM menu WHERE id='$id'");
$data = mysqli_fetch_assoc($query);

// Jika ID tidak ditemukan, kembalikan ke menu.php
if (!$data) {
    header("Location: ../menu.php");
    exit;
}

// PROSES UPDATE DATA
if (isset($_POST['update'])) {
    $nama_menu = mysqli_real_escape_string($conn, $_POST['nama_menu']);
    $kategori  = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga     = $_POST['harga'];
    $status    = $_POST['status'];

    // Cek jika user mengunggah foto baru
    if (!empty($_FILES['foto']['name'])) {
        $nama_foto = time() . '_' . $_FILES['foto']['name'];
        $tmp_foto  = $_FILES['foto']['tmp_name'];
        
        move_uploaded_file($tmp_foto, "../uploads/" . $nama_foto);

        $update = mysqli_query($conn, "UPDATE menu SET 
            nama_menu='$nama_menu', 
            kategori='$kategori', 
            harga='$harga', 
            status='$status',
            foto='$nama_foto'
            WHERE id='$id'");
    } else {
        // Update tanpa mengubah foto
        $update = mysqli_query($conn, "UPDATE menu SET 
            nama_menu='$nama_menu', 
            kategori='$kategori', 
            harga='$harga', 
            status='$status' 
            WHERE id='$id'");
    }

    if ($update) {
        header("Location: ../menu.php");
        exit;
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu - Nasi Uduk Hj. Mina</title>
    <!-- CSS keluar dari folder proses -->
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .form-box {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            max-width: 500px;
            margin: 20px auto;
        }
        .form-box label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-top: 12px;
            margin-bottom: 4px;
            color: #374151;
        }
        .form-box input, .form-box select {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            box-sizing: border-box;
        }
        .btn-submit {
            background: #ea580c;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
        }
        .btn-batal {
            background: #6b7280;
            color: white;
            text-decoration: none;
            padding: 9px 16px;
            border-radius: 8px;
            font-weight: bold;
            font-size: 14px;
            display: inline-block;
            margin-top: 15px;
            margin-left: 5px;
        }
    </style>
</head>
<body>

<!-- Sidebar keluar dari folder proses -->
<?php include "../sidebar.php"; ?>

<div class="content">
    <h1>Edit Data Menu</h1>

    <div class="form-box">
        <form action="" method="POST" enctype="multipart/form-data">

            <label>Nama Menu</label>
            <input type="text" name="nama_menu" value="<?= htmlspecialchars($data['nama_menu']) ?>" required>

            <label>Kategori</label>
            <select name="kategori" required>
                <option value="Nasi Uduk" <?= $data['kategori'] == 'Nasi Uduk' ? 'selected' : '' ?>>Nasi Uduk</option>
                <option value="Lauk" <?= $data['kategori'] == 'Lauk' ? 'selected' : '' ?>>Lauk</option>
                <option value="Tambahan" <?= $data['kategori'] == 'Tambahan' ? 'selected' : '' ?>>Tambahan</option>
                <option value="Minuman" <?= $data['kategori'] == 'Minuman' ? 'selected' : '' ?>>Minuman</option>
            </select>

            <label>Harga</label>
            <input type="number" name="harga" value="<?= $data['harga'] ?>" required>

            <label>Status</label>
            <select name="status">
                <option value="Tersedia" <?= $data['status'] == 'Tersedia' ? 'selected' : '' ?>>Tersedia</option>
                <option value="Habis" <?= $data['status'] == 'Habis' ? 'selected' : '' ?>>Habis</option>
            </select>

            <label>Foto Menu Saat Ini</label>
            <?php if (!empty($data['foto'])): ?>
                <img src="../uploads/<?= $data['foto'] ?>" width="100" style="border-radius: 6px; margin: 8px 0; display: block;" onerror="this.src='https://via.placeholder.com/100?text=No+Image';">
            <?php endif; ?>
            <input type="file" name="foto" accept="image/*">
            <small style="color: #6b7280;">*Biarkan kosong jika tidak ingin mengganti foto</small>

            <br>
            <button type="submit" name="update" class="btn-submit">Simpan Perubahan</button>
            <a href="../menu.php" class="btn-batal">Batal</a>

        </form>
    </div>
</div>

</body>
</html>
<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

/* Ambil semua transaksi */
$query = mysqli_query(
    $conn,
    "SELECT * FROM transaksi ORDER BY tanggal DESC"
);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi - Nasi Uduk Hj. Mina</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .table-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            overflow-x: auto;
        }

        .btn-detail {
            background: #2563eb;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
        }

        .detail-row {
            display: none;
            background: #f9fafb;
        }

        .detail-content {
            padding: 15px 30px;
        }

        .detail-table {
            width: 100%;
            margin-top: 10px;
            background: white;
        }

        .detail-table th {
            background: #ea580c;
            color: white;
            padding: 8px;
        }

        .detail-table td {
            padding: 8px;
            border-bottom: 1px solid #eee;
        }

        .status {
            padding: 5px 10px;
            border-radius: 5px;
            background: #dcfce7;
            color: #166534;
        }

        .empty {
            text-align: center;
            padding: 30px;
            color: #777;
        }
    </style>
</head>

<body>

<!-- PEMANGGILAN SIDEBAR TERPUSAT -->
<?php include "sidebar.php"; ?>

<!-- CONTENT -->
<div class="content">
    <h1>Riwayat Transaksi</h1>
    <p>Daftar seluruh transaksi yang telah dilakukan.</p>

    <div class="table-box">
        <table>
            <tr>
                <th>No</th>
                <th>Kode Transaksi</th>
                <th>Tanggal</th>
                <th>Total</th>
                <th>Metode</th>
                <th>Bayar</th>
                <th>Kembalian</th>
                <th>Detail</th>
            </tr>

            <?php
            $no = 1;
            if (mysqli_num_rows($query) > 0):
                while ($row = mysqli_fetch_assoc($query)):
            ?>

            <!-- BARIS UTAMA TRANSAKSI -->
            <tr>
                <td><?= $no ?></td>
                <td><strong><?= htmlspecialchars($row['kode_transaksi']) ?></strong></td>
                <td><?= date("d-m-Y H:i", strtotime($row['tanggal'])) ?></td>
                <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                <td><span class="status"><?= htmlspecialchars($row['metode_pembayaran']) ?></span></td>
                <td>Rp <?= number_format($row['bayar'], 0, ',', '.') ?></td>
                <td>Rp <?= number_format($row['kembalian'], 0, ',', '.') ?></td>
                <td>
                    <button class="btn-detail" onclick="lihatDetail(<?= $row['id'] ?>)">Lihat</button>
                    <a href="struk.php?id=<?= $row['id'] ?>" target="_blank" class="btn-detail" style="background:#059669; text-decoration:none; display:inline-block; margin-left:4px;">Struk</a>
                </td>
            </tr>

            <!-- BARIS DETAIL (ACCORDION) -->
            <tr id="detail-<?= $row['id'] ?>" class="detail-row">
                <td colspan="8">
                    <div class="detail-content">
                        <strong>Detail Pesanan</strong>
                        <?php
                        $transaksi_id = $row['id'];
                        $detail = mysqli_query(
                            $conn,
                            "SELECT detail_transaksi.*, menu.nama_menu 
                             FROM detail_transaksi 
                             JOIN menu ON detail_transaksi.menu_id = menu.id 
                             WHERE transaksi_id = $transaksi_id"
                        );
                        ?>

                        <table class="detail-table">
                            <tr>
                                <th>Menu</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Subtotal</th>
                            </tr>
                            <?php while ($item = mysqli_fetch_assoc($detail)): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['nama_menu']) ?></td>
                                <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                <td><?= $item['jumlah'] ?></td>
                                <td>Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </table>
                    </div>
                </td>
            </tr>

            <?php
                $no++;
                endwhile;
            else:
            ?>
            <tr>
                <td colspan="8" class="empty">Belum ada transaksi.</td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<script>
function lihatDetail(id) {
    const detail = document.getElementById("detail-" + id);
    if (detail.style.display === "table-row") {
        detail.style.display = "none";
    } else {
        detail.style.display = "table-row";
    }
}
</script>

</body>
</html>
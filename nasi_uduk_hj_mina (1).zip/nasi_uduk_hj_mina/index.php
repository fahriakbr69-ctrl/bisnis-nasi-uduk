<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

$total_menu = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM menu")
)['total'];

$total_transaksi = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi")
)['total'];

$penjualan = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COALESCE(SUM(total),0) AS total FROM transaksi")
)['total'];

$hari_ini = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(tanggal)=CURDATE()"))[0];
$pesanan_aktif = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pesanan WHERE status_pesanan IN('Baru','Diproses','Siap')"))[0];
$menunggu_verif = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pesanan WHERE status_bayar='Menunggu Verifikasi'"))[0];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Nasi Uduk Hj. Mina</title>
    <link rel="stylesheet" href="assets/style.css">
    
    <style>
        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 25px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,.06);
            border-left: 4px solid #ea580c;
        }

        .card h3 {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .card h2 {
            color: #1f2937;
            font-size: 24px;
            margin: 0;
        }
    </style>
</head>

<body>

<!-- PEMANGGILAN SIDEBAR TERPUSAT BERLOGO -->
<?php include "sidebar.php"; ?>

<!-- CONTENT -->
<div class="content">

    <h1>Dashboard</h1>
    <p>Selamat datang di POS Nasi Uduk Hj. Mina</p>

    <div class="cards">

        <div class="card">
            <h3>Total Menu</h3>
            <h2><?= $total_menu ?></h2>
        </div>

        <div class="card">
            <h3>Total Transaksi</h3>
            <h2><?= $total_transaksi ?></h2>
        </div>

        <div class="card">
            <h3>Total Penjualan</h3>
            <h2>Rp <?= number_format($penjualan, 0, ',', '.') ?></h2>
        </div>

        <div class="card">
            <h3>Penjualan Hari Ini</h3>
            <h2>Rp <?= number_format($hari_ini, 0, ',', '.') ?></h2>
        </div>

        <div class="card">
            <h3>Pesanan Online Aktif</h3>
            <h2><?= $pesanan_aktif ?></h2>
        </div>

        <div class="card">
            <h3>Menunggu Verifikasi Bayar</h3>
            <h2><?= $menunggu_verif ?></h2>
        </div>

    </div>

</div>

</body>
</html>
<?php
include "header.php";
$rows = mysqli_fetch_all(mysqli_query($conn,
    "SELECT * FROM menu ORDER BY FIELD(kategori,'Nasi Uduk','Lauk','Tambahan','Minuman'), nama_menu"
), MYSQLI_ASSOC);
$kategori = array_unique(array_column($rows, 'kategori'));
?>
<h1>Menu Hari Ini</h1>
<div class="tabs">
    <button class="on" data-k="">Semua</button>
    <?php foreach ($kategori as $k): ?>
    <button data-k="<?= htmlspecialchars($k) ?>"><?= htmlspecialchars($k) ?></button>
    <?php endforeach; ?>
</div>
<div class="grid">
    <?php foreach ($rows as $r): ?>
    <div class="p" data-k="<?= htmlspecialchars($r['kategori']) ?>">
        <img src="<?= BASE ?>uploads/<?= rawurlencode($r['foto']) ?>" alt="" onerror="this.style.visibility='hidden'">
        <div class="b">
            <small><?= htmlspecialchars($r['kategori']) ?></small>
            <h3><?= htmlspecialchars($r['nama_menu']) ?></h3>
            <div class="pr">Rp <?= number_format($r['harga'], 0, ',', '.') ?></div>
            <?php if ($r['status'] == 'Tersedia'): ?>
            <div class="qty">
                <button onclick="ubah(<?= $r['id'] ?>,-1)">−</button>
                <span id="q<?= $r['id'] ?>">0</span>
                <button onclick="ubah(<?= $r['id'] ?>,1)">+</button>
            </div>
            <?php else: ?>
            <span class="tag r">Habis</span>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<div class="bar" id="bar"><span id="info"></span><span><a class="btn" href="#" onclick="return batal()" style="background:#9ca3af;margin-right:8px">Batalkan</a><a class="btn" href="checkout.php">Lanjut Bayar</a></span></div>
<script>
const HARGA = {<?php foreach ($rows as $r) echo $r['id'] . ':' . (int)$r['harga'] . ','; ?>};
let cart = JSON.parse(localStorage.cart || "{}");

function ubah(id, d) {
    cart[id] = Math.max(0, (cart[id] || 0) + d);
    if (!cart[id]) delete cart[id];
    localStorage.cart = JSON.stringify(cart);
    draw();
}
function batal() {
    if (confirm('Kosongkan pilihan menu?')) { cart = {}; localStorage.removeItem('cart'); draw(); }
    return false;
}
function draw() {
    let n = 0, t = 0;
    document.querySelectorAll('[id^=q]').forEach(e => e.textContent = cart[e.id.slice(1)] || 0);
    for (const i in cart) { n += cart[i]; t += cart[i] * (HARGA[i] || 0); }
    document.getElementById('bar').style.display = n ? 'flex' : 'none';
    document.getElementById('info').textContent = n + ' item · Rp ' + t.toLocaleString('id-ID');
}
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => {
    document.querySelectorAll('.tabs button').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
    document.querySelectorAll('.p').forEach(p => p.style.display = (!b.dataset.k || p.dataset.k == b.dataset.k) ? '' : 'none');
});
draw();
</script>
</main>
</body>
</html>

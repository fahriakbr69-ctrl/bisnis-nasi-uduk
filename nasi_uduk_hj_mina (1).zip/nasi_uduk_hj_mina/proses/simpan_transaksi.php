<?php
require_once __DIR__."/../auth.php"; wajib_admin();

include "../koneksi.php";


/* Ambil data dari kasir */

$keranjang = json_decode($_POST['keranjang'], true);

$metode = $_POST['metode_pembayaran'];

$bayar = intval($_POST['bayar']);


/* Validasi */

if (!$keranjang || count($keranjang) == 0) {

    die("Keranjang kosong.");

}


/* Hitung total dari database */

$total = 0;

foreach ($keranjang as $item) {

    $menu_id = intval($item['id']);
    $jumlah = intval($item['jumlah']);

    $query = mysqli_query(
        $conn,
        "SELECT harga FROM menu WHERE id=$menu_id"
    );

    $menu = mysqli_fetch_assoc($query);

    if (!$menu) {
        die("Menu tidak ditemukan.");
    }

    $harga = intval($menu['harga']);

    $total += $harga * $jumlah;

}


/* Cek pembayaran */

if ($bayar < $total) {

    die("Pembayaran kurang.");

}


$kembalian = $bayar - $total;


/* Buat kode transaksi */

$kode = "TRX-" . date("YmdHis");


/* Mulai transaksi database */

mysqli_begin_transaction($conn);


try {

    /* Simpan transaksi */

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO transaksi
        (kode_transaksi,total,metode_pembayaran,bayar,kembalian)
        VALUES (?,?,?,?,?)"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "sisis",
        $kode,
        $total,
        $metode,
        $bayar,
        $kembalian
    );

    mysqli_stmt_execute($stmt);


    $transaksi_id = mysqli_insert_id($conn);


    /* Simpan detail transaksi */

    foreach ($keranjang as $item) {

        $menu_id = intval($item['id']);

        $jumlah = intval($item['jumlah']);


        $query = mysqli_query(
            $conn,
            "SELECT harga FROM menu WHERE id=$menu_id"
        );

        $menu = mysqli_fetch_assoc($query);

        $harga = intval($menu['harga']);

        $subtotal = $harga * $jumlah;


        $stmt_detail = mysqli_prepare(
            $conn,
            "INSERT INTO detail_transaksi
            (transaksi_id,menu_id,jumlah,harga,subtotal)
            VALUES (?,?,?,?,?)"
        );


        mysqli_stmt_bind_param(
            $stmt_detail,
            "iiiii",
            $transaksi_id,
            $menu_id,
            $jumlah,
            $harga,
            $subtotal
        );


        mysqli_stmt_execute($stmt_detail);

    }


    mysqli_commit($conn);


    /* Arahkan ke halaman struk */

    header(
        "Location: ../struk.php?id=" . $transaksi_id
    );

    exit;


} catch (Exception $e) {

    mysqli_rollback($conn);

    die("Transaksi gagal: " . $e->getMessage());

}

?>
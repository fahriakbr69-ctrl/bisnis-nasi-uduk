<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

/* =========================
   FILTER TANGGAL
========================= */
$tanggal_awal = isset($_GET['tanggal_awal'])
    ? $_GET['tanggal_awal']
    : date('Y-m-01');

$tanggal_akhir = isset($_GET['tanggal_akhir'])
    ? $_GET['tanggal_akhir']
    : date('Y-m-d');


/* =========================
   TOTAL PENJUALAN
========================= */
$query_total = mysqli_query(
    $conn,
    "SELECT
        COALESCE(SUM(total),0) AS total_penjualan,
        COUNT(*) AS jumlah_transaksi,
        COALESCE(AVG(total),0) AS rata_transaksi
     FROM transaksi
     WHERE DATE(tanggal)
     BETWEEN '$tanggal_awal'
     AND '$tanggal_akhir'"
);

$data_total = mysqli_fetch_assoc($query_total);

$total_penjualan = $data_total['total_penjualan'];
$jumlah_transaksi = $data_total['jumlah_transaksi'];
$rata_transaksi = $data_total['rata_transaksi'];


/* =========================
   PENJUALAN HARI INI
========================= */
$hari_ini = date('Y-m-d');

$query_hari_ini = mysqli_query(
    $conn,
    "SELECT
        COALESCE(SUM(total),0) AS total
     FROM transaksi
     WHERE DATE(tanggal) = '$hari_ini'"
);

$data_hari_ini = mysqli_fetch_assoc($query_hari_ini);
$penjualan_hari_ini = $data_hari_ini['total'];


/* =========================
   LAPORAN HARIAN
========================= */
$query_harian = mysqli_query(
    $conn,
    "SELECT
        DATE(tanggal) AS tanggal,
        COUNT(*) AS jumlah_transaksi,
        SUM(total) AS total
     FROM transaksi
     WHERE DATE(tanggal)
     BETWEEN '$tanggal_awal'
     AND '$tanggal_akhir'
     GROUP BY DATE(tanggal)
     ORDER BY tanggal DESC"
);


/* =========================
   LAPORAN BULANAN
========================= */
$query_bulanan = mysqli_query(
    $conn,
    "SELECT
        DATE_FORMAT(tanggal,'%Y-%m') AS bulan,
        COUNT(*) AS jumlah_transaksi,
        SUM(total) AS total
     FROM transaksi
     GROUP BY DATE_FORMAT(tanggal,'%Y-%m')
     ORDER BY bulan DESC"
);


/* =========================
   MENU TERLARIS
========================= */
$query_terlaris = mysqli_query(
    $conn,
    "SELECT
        menu.nama_menu,
        SUM(detail_transaksi.jumlah) AS jumlah_terjual,
        SUM(detail_transaksi.subtotal) AS total_penjualan
     FROM detail_transaksi
     JOIN menu ON detail_transaksi.menu_id = menu.id
     JOIN transaksi ON detail_transaksi.transaksi_id = transaksi.id
     WHERE DATE(transaksi.tanggal) BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
     GROUP BY detail_transaksi.menu_id
     ORDER BY jumlah_terjual DESC
     LIMIT 10"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - Nasi Uduk Hj. Mina</title>
    <link rel="stylesheet" href="assets/style.css">

    <style>
        .report-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 25px;
        }

        .report-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,.06);
        }

        .report-card h3 {
            color: #777;
            font-size: 15px;
            margin-bottom: 10px;
        }

        .report-card h2 {
            color: #ea580c;
        }

        .filter-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
        }

        .filter-form {
            display: grid;
            grid-template-columns: 1fr 1fr auto;
            gap: 15px;
            align-items: end;
        }

        .filter-form input {
            margin-bottom: 0;
        }

        .section {
            margin-top: 30px;
        }

        .section-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 15px;
        }

        .badge {
            background: #fed7aa;
            color: #9a3412;
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<!-- PEMANGGILAN SIDEBAR TERPUSAT -->
<?php include "sidebar.php"; ?>

<!-- CONTENT -->
<div class="content">

    <h1>Laporan Penjualan</h1>
    <p>Rekap penjualan Nasi Uduk Hj. Mina.</p>

    <!-- FILTER -->
    <div class="filter-box">
        <h3>Filter Periode</h3>
        <form class="filter-form" method="GET">
            <div>
                <label>Tanggal Awal</label>
                <input type="date" name="tanggal_awal" value="<?= $tanggal_awal ?>" required>
            </div>

            <div>
                <label>Tanggal Akhir</label>
                <input type="date" name="tanggal_akhir" value="<?= $tanggal_akhir ?>" required>
            </div>

            <button type="submit" class="btn">Tampilkan</button>
        </form>
    </div>

    <!-- CARDS -->
    <div class="report-cards">
        <div class="report-card">
            <h3>Total Penjualan</h3>
            <h2>Rp <?= number_format($total_penjualan, 0, ',', '.') ?></h2>
        </div>

        <div class="report-card">
            <h3>Jumlah Transaksi</h3>
            <h2><?= $jumlah_transaksi ?></h2>
        </div>

        <div class="report-card">
            <h3>Rata-rata Transaksi</h3>
            <h2>Rp <?= number_format($rata_transaksi, 0, ',', '.') ?></h2>
        </div>

        <div class="report-card">
            <h3>Penjualan Hari Ini</h3>
            <h2>Rp <?= number_format($penjualan_hari_ini, 0, ',', '.') ?></h2>
        </div>
    </div>

    <!-- LAPORAN HARIAN -->
    <div class="section">
        <h2>Laporan Harian</h2>
        <div class="section-box">
            <table>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Jumlah Transaksi</th>
                    <th>Total Penjualan</th>
                </tr>

                <?php
                $no = 1;
                if (mysqli_num_rows($query_harian) > 0):
                    while ($row = mysqli_fetch_assoc($query_harian)):
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= date("d-m-Y", strtotime($row['tanggal'])) ?></td>
                    <td><?= $row['jumlah_transaksi'] ?></td>
                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                </tr>
                <?php
                    endwhile;
                else:
                ?>
                <tr>
                    <td colspan="4" style="text-align: center;">Belum ada data.</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <!-- LAPORAN BULANAN -->
    <div class="section">
        <h2>Laporan Bulanan</h2>
        <div class="section-box">
            <table>
                <tr>
                    <th>No</th>
                    <th>Bulan</th>
                    <th>Jumlah Transaksi</th>
                    <th>Total Penjualan</th>
                </tr>

                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($query_bulanan)):
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= date("F Y", strtotime($row['bulan'] . "-01")) ?></td>
                    <td><?= $row['jumlah_transaksi'] ?></td>
                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>

    <!-- MENU TERLARIS -->
    <div class="section">
        <h2>Menu Terlaris</h2>
        <div class="section-box">
            <table>
                <tr>
                    <th>Peringkat</th>
                    <th>Nama Menu</th>
                    <th>Jumlah Terjual</th>
                    <th>Total Penjualan</th>
                </tr>

                <?php
                $no = 1;
                if (mysqli_num_rows($query_terlaris) > 0):
                    while ($row = mysqli_fetch_assoc($query_terlaris)):
                ?>
                <tr>
                    <td><span class="badge"><?= $no++ ?></span></td>
                    <td><?= htmlspecialchars($row['nama_menu']) ?></td>
                    <td><?= $row['jumlah_terjual'] ?></td>
                    <td>Rp <?= number_format($row['total_penjualan'], 0, ',', '.') ?></td>
                </tr>
                <?php
                    endwhile;
                else:
                ?>
                <tr>
                    <td colspan="4" style="text-align: center;">Belum ada data penjualan.</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

</div>

</body>
</html>
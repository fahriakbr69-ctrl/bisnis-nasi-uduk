<?php
require_once __DIR__."/auth.php"; wajib_admin();

include "koneksi.php";

$id = intval($_GET['id']);


/* Data transaksi */

$query = mysqli_query(
    $conn,
    "SELECT * FROM transaksi WHERE id=$id"
);

$transaksi = mysqli_fetch_assoc($query);


if (!$transaksi) {

    die("Transaksi tidak ditemukan.");

}


/* Detail transaksi */

$detail = mysqli_query(
    $conn,
    "SELECT
        detail_transaksi.*,
        menu.nama_menu
     FROM detail_transaksi
     JOIN menu
     ON detail_transaksi.menu_id = menu.id
     WHERE transaksi_id=$id"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<title>Struk <?= $transaksi['kode_transaksi'] ?></title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #eee;
}

.struk {
    width: 380px;
    margin: 30px auto;
    background: white;
    padding: 25px;
}

.center {
    text-align: center;
}

.item {
    display: flex;
    justify-content: space-between;
    margin: 10px 0;
}

hr {
    border: none;
    border-top: 1px dashed #777;
}

.total {
    font-weight: bold;
    font-size: 18px;
}

.btn {
    padding: 10px 15px;
    background: #ea580c;
    color: white;
    border: none;
    cursor: pointer;
}

@media print {

    .no-print {
        display: none;
    }

    body {
        background: white;
    }

    .struk {
        margin: 0;
        width: 100%;
    }

}

</style>

</head>

<body>

<div class="struk">

    <div class="center">

        <h2>Nasi Uduk Hj. Mina</h2>

        <p>Struk Pembayaran</p>

        <small>
            <?= $transaksi['kode_transaksi'] ?>
        </small>

        <br>

        <small>
            <?= date(
                "d-m-Y H:i",
                strtotime($transaksi['tanggal'])
            ) ?>
        </small>

    </div>

    <hr>


    <?php while ($row = mysqli_fetch_assoc($detail)): ?>

        <div class="item">

            <div>

                <?= htmlspecialchars($row['nama_menu']) ?>

                <br>

                <?= $row['jumlah'] ?> x
                Rp <?= number_format(
                    $row['harga'],
                    0,
                    ',',
                    '.'
                ) ?>

            </div>

            <div>

                Rp <?= number_format(
                    $row['subtotal'],
                    0,
                    ',',
                    '.'
                ) ?>

            </div>

        </div>

    <?php endwhile; ?>


    <hr>

    <p>
        Total:
        <strong>
            Rp <?= number_format(
                $transaksi['total'],
                0,
                ',',
                '.'
            ) ?>
        </strong>
    </p>

    <p>
        Pembayaran:
        <?= $transaksi['metode_pembayaran'] ?>
    </p>

    <p>
        Bayar:
        Rp <?= number_format(
            $transaksi['bayar'],
            0,
            ',',
            '.'
        ) ?>
    </p>

    <p>
        Kembalian:
        Rp <?= number_format(
            $transaksi['kembalian'],
            0,
            ',',
            '.'
        ) ?>
    </p>

    <hr>

    <div class="center">

        <p>Terima kasih</p>

        <button
            class="btn no-print"
            onclick="window.print()">

            Cetak Struk

        </button>

        <a
            class="no-print"
            href="kasir.php">

            Transaksi Baru

        </a>

    </div>

</div>

</body>

</html>
<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM menu WHERE status='Tersedia' ORDER BY kategori, nama_menu");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir - Nasi Uduk Hj. Mina</title>
    <link rel="stylesheet" href="assets/style.css">

    <style>
        /* LAYOUT KASIR */
        .kasir-container {
            display: grid;
            grid-template-columns: 2.2fr 1fr;
            gap: 20px;
        }

        .menu-area,
        .cart-area {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        /* GRID MENU RAPI */
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 15px;
        }

        .menu-card {
            cursor: pointer;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            padding: 12px;
            background: #fff;
            transition: all 0.2s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
        }

        .menu-card:hover {
            border-color: #ea580c;
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(234, 88, 12, 0.15);
        }

        /* BATASAN GAMBAR MENU */
        .menu-card img, 
        .menu-card .no-photo {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 10px;
            display: block;
        }

        .menu-card .no-photo {
            background-color: #f3f4f6;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-size: 12px;
            font-weight: 500;
        }

        .menu-card h3 {
            font-size: 15px;
            font-weight: 600;
            color: #1f2937;
            margin: 0 0 4px 0;
            line-height: 1.3;
        }

        .menu-card .kategori-badge {
            font-size: 11px;
            color: #6b7280;
            background: #f3f4f6;
            padding: 2px 8px;
            border-radius: 4px;
            display: inline-block;
            margin-bottom: 8px;
            width: fit-content;
        }

        .menu-card .price {
            font-size: 14px;
            font-weight: 700;
            color: #ea580c;
            margin: 0;
        }

        /* INPUT CARI */
        .search {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }

        .search:focus {
            outline: none;
            border-color: #ea580c;
        }

        /* KERANJANG */
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #f3f4f6;
            padding: 10px 0;
        }

        .qty button {
            padding: 2px 8px;
            border: 1px solid #d1d5db;
            background: #fff;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        .qty button:hover {
            background: #f3f4f6;
        }

        .total-box {
            margin-top: 20px;
            border-top: 2px solid #e5e7eb;
            padding-top: 15px;
        }

        .total {
            font-size: 22px;
            font-weight: bold;
            color: #ea580c;
            margin-bottom: 15px;
        }

        .total-box label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-top: 10px;
            margin-bottom: 4px;
            color: #374151;
        }

        .total-box select,
        .total-box input[type="number"] {
            width: 100%;
            padding: 9px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        .btn-bayar {
            width: 100%;
            background: #16a34a;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: bold;
            padding: 12px;
            margin-top: 15px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-bayar:hover {
            background: #15803d;
        }
    </style>
</head>

<body>

<!-- PEMANGGILAN SIDEBAR TERPUSAT BERLOGO -->
<?php include "sidebar.php"; ?>

<div class="content">

    <h1>Kasir</h1>

    <div class="kasir-container">

        <!-- MENU AREA -->
        <div class="menu-area">
            <h2>Daftar Menu</h2>

            <input
                type="text"
                id="search"
                class="search"
                placeholder="Cari menu..."
                onkeyup="cariMenu()"
            >

            <div class="menu-grid" id="menuList">
                <?php while ($row = mysqli_fetch_assoc($data)): ?>
                    <div
                        class="menu-card"
                        data-nama="<?= strtolower($row['nama_menu']) ?>"
                        onclick="tambahKeranjang(
                            <?= $row['id'] ?>,
                            '<?= htmlspecialchars($row['nama_menu'], ENT_QUOTES) ?>',
                            <?= $row['harga'] ?>
                        )"
                    >
                        <div>
                            <?php if (!empty($row['foto'])): ?>
                                <img src="uploads/<?= $row['foto'] ?>" 
                                     alt="<?= htmlspecialchars($row['nama_menu']) ?>"
                                     onerror="this.onerror=null; this.src='https://via.placeholder.com/180x120?text=Tanpa+Foto';">
                            <?php else: ?>
                                <div class="no-photo">Tanpa Foto</div>
                            <?php endif; ?>

                            <h3><?= htmlspecialchars($row['nama_menu']) ?></h3>
                            <span class="kategori-badge"><?= htmlspecialchars($row['kategori']) ?></span>
                        </div>

                        <p class="price">Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- KERANJANG AREA -->
        <div class="cart-area">
            <h2>Pesanan</h2>

            <div id="cart">
                <p style="color: #9ca3af; font-size: 14px;">Belum ada pesanan.</p>
            </div>

            <div class="total-box">
                <p style="margin: 0; font-size: 13px; color: #6b7280;">Total Pembayaran</p>
                <div class="total">
                    Rp <span id="total">0</span>
                </div>

                <form
                    action="proses/simpan_transaksi.php"
                    method="POST"
                    onsubmit="return prosesBayar()"
                >
                    <input type="hidden" name="keranjang" id="keranjangInput">

                    <label>Metode Pembayaran</label>
                    <select name="metode_pembayaran" id="metode" required onchange="cekMetodePembayaran()">
                        <option value="">Pilih metode</option>
                        <option value="Tunai">Tunai</option>
                        <option value="QRIS">QRIS</option>
                        <option value="Transfer">Transfer</option>
                    </select>

                    <label>Uang Dibayar</label>
                    <input
                        type="number"
                        name="bayar"
                        id="bayar"
                        placeholder="Masukkan nominal"
                        required
                        oninput="hitungKembalian()"
                    >

                    <p style="font-size: 14px; margin-top: 10px;">
                        Kembalian: <strong>Rp <span id="kembalian">0</span></strong>
                    </p>

                    <button class="btn-bayar" type="submit">
                        BAYAR & SIMPAN TRANSAKSI
                    </button>
                </form>
            </div>
        </div>

    </div>

</div>

<script>
let keranjang = [];

/* TAMBAH MENU */
function tambahKeranjang(id, nama, harga) {
    let item = keranjang.find(item => item.id === id);

    if (item) {
        item.jumlah++;
    } else {
        keranjang.push({
            id: id,
            nama: nama,
            harga: harga,
            jumlah: 1
        });
    }

    tampilkanKeranjang();
}

/* TAMPILKAN KERANJANG */
function tampilkanKeranjang() {
    let cart = document.getElementById("cart");

    if (keranjang.length === 0) {
        cart.innerHTML = '<p style="color: #9ca3af; font-size: 14px;">Belum ada pesanan.</p>';
        document.getElementById("total").innerText = "0";
        hitungKembalian();
        return;
    }

    let html = "";
    let total = 0;

    keranjang.forEach((item, index) => {
        let subtotal = item.harga * item.jumlah;
        total += subtotal;

        html += `
            <div class="cart-item">
                <div>
                    <strong style="font-size: 14px; color: #1f2937;">${item.nama}</strong><br>
                    <small style="color: #6b7280;">Rp ${item.harga.toLocaleString('id-ID')} x ${item.jumlah}</small><br>
                    <span style="font-size: 13px; font-weight: 600; color: #ea580c;">Rp ${subtotal.toLocaleString('id-ID')}</span>
                </div>
                <div class="qty">
                    <button type="button" onclick="kurang(${index})">-</button>
                    <span style="margin: 0 6px; font-weight: 600;">${item.jumlah}</span>
                    <button type="button" onclick="tambah(${index})">+</button>
                </div>
            </div>
        `;
    });

    cart.innerHTML = html;
    document.getElementById("total").innerText = total.toLocaleString('id-ID');
    cekMetodePembayaran();
    hitungKembalian();
}

/* TAMBAH JUMLAH */
function tambah(index) {
    keranjang[index].jumlah++;
    tampilkanKeranjang();
}

/* KURANG JUMLAH */
function kurang(index) {
    keranjang[index].jumlah--;
    if (keranjang[index].jumlah <= 0) {
        keranjang.splice(index, 1);
    }
    tampilkanKeranjang();
}

/* HITUNG TOTAL */
function getTotal() {
    let total = 0;
    keranjang.forEach(item => {
        total += item.harga * item.jumlah;
    });
    return total;
}

/* HITUNG KEMBALIAN */
function hitungKembalian() {
    let total = getTotal();
    let bayar = parseInt(document.getElementById("bayar").value) || 0;
    let kembalian = bayar - total;

    if (kembalian < 0) {
        kembalian = 0;
    }

    document.getElementById("kembalian").innerText = kembalian.toLocaleString('id-ID');
}

/* OTOMATIS ISI NOMINAL DIBAYAR JIKA QRIS / TRANSFER */
function cekMetodePembayaran() {
    let metode = document.getElementById("metode").value;
    let total = getTotal();
    let inputBayar = document.getElementById("bayar");

    if (metode === "QRIS" || metode === "Transfer") {
        inputBayar.value = total;
    }
    hitungKembalian();
}

/* PROSES BAYAR */
function prosesBayar() {
    if (keranjang.length === 0) {
        alert("Keranjang masih kosong!");
        return false;
    }

    let total = getTotal();
    let bayar = parseInt(document.getElementById("bayar").value) || 0;

    if (bayar < total) {
        alert("Uang pembayaran kurang!");
        return false;
    }

    document.getElementById("keranjangInput").value = JSON.stringify(keranjang);
    return true;
}

/* SEARCH MENU */
function cariMenu() {
    let keyword = document.getElementById("search").value.toLowerCase();
    let menu = document.querySelectorAll(".menu-card");

    menu.forEach(item => {
        let nama = item.dataset.nama;
        if (nama.includes(keyword)) {
            item.style.display = "flex";
        } else {
            item.style.display = "none";
        }
    });
}
</script>

</body>
</html>
<?php
include "header.php";
$menu = [];
foreach (mysqli_query($conn, "SELECT id,nama_menu,harga FROM menu WHERE status='Tersedia'") as $r) {
    $menu[$r['id']] = $r;
}
?>
<h1>Checkout &amp; Pembayaran</h1>
<form method="post" action="<?= BASE ?>proses/pesan_user.php" class="box" onsubmit="return kirim()">
    <h3>Ringkasan Pesanan</h3>
    <table id="tabel"></table><br>
    <label>Nama Pemesan</label>
    <input name="nama_pemesan" required placeholder="Nama Anda" maxlength="100">
    <label>Metode Pembayaran</label>
    <select name="metode">
        <option value="Tunai">Tunai (bayar di kasir)</option>
        <option value="QRIS">QRIS</option>
        <option value="Transfer">Transfer Bank</option>
    </select>
    <label>Catatan (opsional)</label>
    <input name="catatan" maxlength="200" placeholder="Contoh: sambal dipisah">
    <input type="hidden" name="keranjang" id="keranjang">
    <button>Buat Pesanan</button>
    <a href="index.php" style="margin-left:10px">← Tambah menu</a>
    <a href="#" onclick="return batal()" class="btn" style="background:#9ca3af;margin-left:10px">Batalkan Pesanan</a>
</form>
<script>
const MENU = <?= json_encode($menu) ?>;
let cart = JSON.parse(localStorage.cart || "{}"), total = 0;
let baris = '<tr><th>Menu<th>Qty<th>Subtotal</tr>';
for (const id in cart) {
    if (!MENU[id]) { delete cart[id]; continue; }
    const sub = cart[id] * MENU[id].harga;
    total += sub;
    baris += `<tr><td>${MENU[id].nama_menu}<td>${cart[id]}<td>Rp ${sub.toLocaleString('id-ID')}</tr>`;
}
document.getElementById('tabel').innerHTML = baris + `<tr><th colspan=2>Total<th>Rp ${total.toLocaleString('id-ID')}</tr>`;
function kirim() {
    if (!total) { alert('Keranjang masih kosong'); location = 'index.php'; return false; }
    document.getElementById('keranjang').value = JSON.stringify(cart);
}
function batal() {
    if (confirm('Batalkan pesanan dan kosongkan keranjang?')) { localStorage.removeItem('cart'); location = 'index.php'; }
    return false;
}
</script>
</main>
</body>
</html>

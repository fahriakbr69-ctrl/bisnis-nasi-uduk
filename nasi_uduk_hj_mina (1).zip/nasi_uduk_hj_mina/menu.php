<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

$data = mysqli_query($conn, "SELECT * FROM menu ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Menu - Nasi Uduk Hj. Mina</title>
    <link rel="stylesheet" href="assets/style.css">
    
    <style>
        .form-box {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            max-width: 500px;
        }

        .form-box label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-top: 12px;
            margin-bottom: 4px;
            color: #374151;
        }

        .form-box input, 
        .form-box select {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            box-sizing: border-box;
        }

        .form-box button {
            background: #ea580c;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
            transition: background 0.2s;
        }

        .form-box button:hover {
            background: #c2410c;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            margin-top: 15px;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f3f4f6;
            vertical-align: middle;
        }

        table th {
            background-color: #ea580c;
            color: white;
        }

        .btn {
            display: inline-block;
            padding: 8px 14px;
            background: #ea580c;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 13px;
        }

        .btn-edit {
            background: #2563eb;
        }

        .btn-danger {
            background: #dc2626;
        }

        .img-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
    </style>
</head>

<body>

<!-- PEMANGGILAN SIDEBAR TERPUSAT BERLOGO -->
<?php include "sidebar.php"; ?>

<div class="content">

    <h1>Data Menu</h1>

    <a href="#tambah" class="btn">+ Tambah Menu</a>

    <table>
        <tr>
            <th>No</th>
            <th>Foto</th>
            <th>Nama Menu</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php
        $no = 1;
        if (mysqli_num_rows($data) > 0):
            while ($row = mysqli_fetch_assoc($data)):
        ?>

        <tr>
            <td><?= $no++ ?></td>
            <td>
                <?php if (!empty($row['foto'])): ?>
                    <img src="uploads/<?= $row['foto'] ?>" alt="Foto Menu" class="img-thumb" onerror="this.src='https://via.placeholder.com/60?text=No+Img';">
                <?php else: ?>
                    <span style="color: #9ca3af; font-size: 12px;">Tanpa Foto</span>
                <?php endif; ?>
            </td>
            <td><strong><?= htmlspecialchars($row['nama_menu']) ?></strong></td>
            <td><?= htmlspecialchars($row['kategori']) ?></td>
            <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>

            <td>
                <a class="btn btn-edit"
                   href="proses/edit_menu.php?id=<?= $row['id'] ?>">
                   Edit
                </a>

                <a class="btn btn-danger"
                   href="proses/hapus_menu.php?id=<?= $row['id'] ?>"
                   onclick="return confirm('Hapus menu ini?')">
                   Hapus
                </a>
            </td>
        </tr>

        <?php 
            endwhile; 
        else:
        ?>
        <tr>
            <td colspan="7" style="text-align: center; color: #9ca3af; padding: 20px;">Belum ada data menu.</td>
        </tr>
        <?php endif; ?>

    </table>

    <br><br>

    <div class="form-box" id="tambah">

        <h2>Tambah Menu</h2>

        <!-- Ditambahkan enctype="multipart/form-data" agar mendukung upload file -->
        <form action="proses/tambah_menu.php" method="POST" enctype="multipart/form-data">

            <label>Nama Menu</label>
            <input type="text" name="nama_menu" required placeholder="Contoh: Nasi Uduk Komplit">

            <label>Kategori</label>
            <select name="kategori" required>
                <option value="Nasi Uduk">Nasi Uduk</option>
                <option value="Lauk">Lauk</option>
                <option value="Tambahan">Tambahan</option>
                <option value="Minuman">Minuman</option>
            </select>

            <label>Harga</label>
            <input type="number" name="harga" required placeholder="Contoh: 15000">

            <label>Status</label>
            <select name="status">
                <option value="Tersedia">Tersedia</option>
                <option value="Habis">Habis</option>
            </select>

            <!-- Input Foto Menu Baru -->
            <label>Foto Menu</label>
            <input type="file" name="foto" accept="image/*">

            <button type="submit">Simpan Menu</button>

        </form>

    </div>

</div>

</body>
</html>
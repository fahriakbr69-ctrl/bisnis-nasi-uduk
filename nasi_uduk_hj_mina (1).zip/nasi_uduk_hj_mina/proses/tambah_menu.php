<?php
require_once __DIR__."/../auth.php"; wajib_admin();

include "../koneksi.php";

$nama = $_POST['nama_menu'];
$kategori = $_POST['kategori'];
$harga = $_POST['harga'];
$status = $_POST['status'];

// Tentukan default nama foto jika tidak diunggah
$nama_foto = "";

// Cek apakah ada file foto yang diunggah
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $file_tmp = $_FILES['foto']['tmp_name'];
    $file_name = $_FILES['foto']['name'];
    
    // Beri nama unik agar file tidak saling tertimpa
    $nama_foto = time() . '_' . $file_name;
    $target_dir = "../uploads/" . $nama_foto;

    // Pindahkan file yang diunggah ke folder uploads/
    move_uploaded_file($file_tmp, $target_dir);
}

// Prepared Statement dengan penambahan kolom foto
$stmt = mysqli_prepare(
    $conn,
    "INSERT INTO menu (nama_menu, kategori, harga, status, foto)
     VALUES (?, ?, ?, ?, ?)"
);

// Tipe data: s = string, i = integer (nama, kategori, harga, status, foto)
mysqli_stmt_bind_param(
    $stmt,
    "ssiss",
    $nama,
    $kategori,
    $harga,
    $status,
    $nama_foto
);

mysqli_stmt_execute($stmt);

header("Location: ../menu.php");
exit;

?>
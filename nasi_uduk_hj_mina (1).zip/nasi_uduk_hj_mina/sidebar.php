<div class="sidebar">
    <!-- HEADER SIDEBAR DENGAN LOGO NASI MANGKUK -->
    <div class="sidebar-header">
        <div class="logo-icon-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M2 13c0 4.418 3.582 8 8 8s8-3.582 8-8H2zm15-1a7 7 0 0 0-14 0h14z" />
                <path d="M6 5c.55 0 1 .45 1 1v2c0 .55-.45 1-1 1s-1-.45-1-1V6c0-.55.45-1 1-1zm4-2c.55 0 1 .45 1 1v3c0 .55-.45 1-1 1s-1-.45-1-1V4c0-.55.45-1 1-1zm4 2c.55 0 1 .45 1 1v2c0 .55-.45 1-1 1s-1-.45-1-1V6c0-.55.45-1 1-1z" />
            </svg>
        </div>

        <div class="sidebar-title-box">
            <h2>Nasi Uduk Hj. Mina</h2>
            <p class="subtitle">Sistem Kasir POS</p>
        </div>
    </div>

    <?php $current_page = basename($_SERVER['PHP_SELF']); ?>

    <a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">Dashboard</a>
    <a href="kasir.php" class="<?= $current_page == 'kasir.php' ? 'active' : '' ?>">Kasir</a>
    <a href="menu.php" class="<?= $current_page == 'menu.php' ? 'active' : '' ?>">Data Menu</a>
    <a href="transaksi.php" class="<?= $current_page == 'transaksi.php' ? 'active' : '' ?>">Transaksi</a>
    <a href="laporan.php" class="<?= $current_page == 'laporan.php' ? 'active' : '' ?>">Laporan</a>
    <?php $jml_aktif = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM pesanan WHERE status_pesanan IN('Baru','Diproses','Siap')"))[0] ?? 0; ?>
    <a href="pesanan.php" class="<?= $current_page == 'pesanan.php' ? 'active' : '' ?>">Pesanan Online<?= $jml_aktif ? " ($jml_aktif)" : "" ?></a>
    <a href="logout.php" style="margin-top:30px;background:rgba(0,0,0,.25)">Keluar (<?= htmlspecialchars($_SESSION['admin']['nama'] ?? '') ?>)</a>
</div>
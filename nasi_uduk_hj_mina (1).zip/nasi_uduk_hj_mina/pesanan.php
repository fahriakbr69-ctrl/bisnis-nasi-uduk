<?php
require_once __DIR__."/auth.php"; wajib_admin();
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['id'];
    $aksi = $_POST['aksi'];
    $o = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pesanan WHERE id=$id"));

    if ($o && $aksi == 'lunas' && $o['status_bayar'] != 'Lunas') {
        $kode = "TRX-" . date("YmdHis") . $id;
        mysqli_query($conn, "INSERT INTO transaksi(kode_transaksi,total,metode_pembayaran,bayar,kembalian)
            VALUES('$kode',{$o['total']},'{$o['metode']}',{$o['total']},0)");
        $tid = mysqli_insert_id($conn);
        mysqli_query($conn, "INSERT INTO detail_transaksi(transaksi_id,menu_id,jumlah,harga,subtotal)
            SELECT $tid,menu_id,jumlah,harga,jumlah*harga FROM pesanan_detail WHERE pesanan_id=$id");
        mysqli_query($conn, "UPDATE pesanan SET status_bayar='Lunas', transaksi_id=$tid,
            status_pesanan=IF(status_pesanan='Baru','Diproses',status_pesanan) WHERE id=$id");
    }

    if ($o && $aksi == 'status' && in_array($_POST['s'], ['Diproses','Siap','Selesai','Dibatalkan'])
        && ($_POST['s'] != 'Selesai' || $o['status_bayar'] == 'Lunas')
        && ($_POST['s'] != 'Dibatalkan' || $o['status_bayar'] != 'Lunas')) {
        mysqli_query($conn, "UPDATE pesanan SET status_pesanan='{$_POST['s']}' WHERE id=$id");
    }

    header("Location: pesanan.php");
    exit;
}

$r = mysqli_query($conn, "SELECT * FROM pesanan ORDER BY (status_pesanan IN('Selesai','Dibatalkan')), id DESC");

function tombol($id, $aksi, $status, $label, $kelas = '') {
    return "<form method='post'><input type='hidden' name='id' value='$id'>
            <input type='hidden' name='aksi' value='$aksi'><input type='hidden' name='s' value='$status'>
            <button class='$kelas'>$label</button></form>";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pesanan Online - Nasi Uduk Hj. Mina</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include "sidebar.php"; ?>
<div class="content">
    <h1>Pesanan Online</h1>
    <p>Pesanan yang masuk dari halaman pelanggan. Setelah dikonfirmasi lunas, pesanan otomatis tercatat di Transaksi &amp; Laporan.</p>
    <table>
        <tr><th>Kode</th><th>Pemesan</th><th>Total</th><th>Metode</th><th>Pembayaran</th><th>Status</th><th>Aksi</th></tr>
        <?php if (!mysqli_num_rows($r)): ?>
        <tr><td colspan="7">Belum ada pesanan online.</td></tr>
        <?php else: foreach ($r as $o): $id = $o['id']; ?>
        <tr>
            <td><?= htmlspecialchars($o['kode']) ?><br><small><?= date('d/m H:i', strtotime($o['tanggal'])) ?></small></td>
            <td><?= htmlspecialchars($o['nama_pemesan'] ?? 'Tamu') ?></td>
            <td>Rp <?= number_format($o['total'], 0, ',', '.') ?></td>
            <td><?= htmlspecialchars($o['metode']) ?></td>
            <td><?= tag($o['status_bayar']) ?></td>
            <td><?= tag($o['status_pesanan']) ?></td>
            <td class="aksi">
                <?php if (!in_array($o['status_pesanan'], ['Selesai','Dibatalkan'])): ?>
                    <?php if ($o['status_bayar'] != 'Lunas') echo tombol($id, 'lunas', '', 'Konfirmasi Lunas'); ?>
                    <?php if ($o['status_bayar'] == 'Lunas' && $o['status_pesanan'] == 'Diproses') echo tombol($id, 'status', 'Siap', 'Siap Diambil'); ?>
                    <?php if ($o['status_bayar'] == 'Lunas' && $o['status_pesanan'] == 'Siap') echo tombol($id, 'status', 'Selesai', 'Selesai'); ?>
                    <?php if ($o['status_bayar'] != 'Lunas') echo tombol($id, 'status', 'Dibatalkan', 'Batalkan', 'btn-danger'); ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; endif; ?>
    </table>
</div>
</body>
</html>

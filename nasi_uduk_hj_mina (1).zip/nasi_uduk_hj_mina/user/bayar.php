<?php
include_once __DIR__."/../koneksi.php";

$id = (int)($_GET['id'] ?? 0);
$kode = mysqli_real_escape_string($conn, $_GET['kode'] ?? '');
$o = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pesanan WHERE id=$id AND kode='$kode'"));
if (!$o) { die("Pesanan tidak ditemukan. <a href='lacak.php'>Lacak pesanan</a>"); }

if (isset($_POST['sudah']) && $o['status_bayar'] == 'Belum Bayar' && $o['metode'] != 'Tunai') {
    mysqli_query($conn, "UPDATE pesanan SET status_bayar='Menunggu Verifikasi' WHERE id=$id");
    header("Location: bayar.php?id=$id&kode=" . urlencode($kode));
    exit;
}

include "header.php";
$detail = mysqli_query($conn, "SELECT d.*, m.nama_menu FROM pesanan_detail d JOIN menu m ON m.id=d.menu_id WHERE pesanan_id=$id");
$rp = fn($n) => 'Rp ' . number_format($n, 0, ',', '.');
?>
<h1>Pesanan <?= htmlspecialchars($o['kode']) ?></h1>
<?php if (isset($_GET['baru'])): ?>
<script>localStorage.removeItem('cart')</script>
<div class="ok">Pesanan berhasil dibuat! Selesaikan pembayaran di bawah, dan simpan kode pesanan ini untuk melacaknya nanti.</div>
<?php endif; ?>
<div class="box">
    <table>
        <tr><th>Menu<th>Qty<th>Subtotal</tr>
        <?php foreach ($detail as $x): ?>
        <tr><td><?= htmlspecialchars($x['nama_menu']) ?><td><?= $x['jumlah'] ?><td><?= $rp($x['jumlah'] * $x['harga']) ?></tr>
        <?php endforeach; ?>
        <tr><th colspan=2>Total<th><?= $rp($o['total']) ?></tr>
    </table>
    <p>Pemesan: <b><?= htmlspecialchars($o['nama_pemesan']) ?></b> &nbsp; Metode: <b><?= htmlspecialchars($o['metode']) ?></b><br>
    Pembayaran: <?= tag($o['status_bayar']) ?> &nbsp; Pesanan: <?= tag($o['status_pesanan']) ?></p>
</div>
<?php if ($o['status_bayar'] == 'Belum Bayar' && $o['status_pesanan'] != 'Dibatalkan'): ?>
<div class="box">
    <h3>Cara Pembayaran</h3>
    <?php if ($o['metode'] == 'Tunai'): ?>
    <p>Tunjukkan kode <b><?= htmlspecialchars($o['kode']) ?></b> ke kasir dan bayar <b><?= $rp($o['total']) ?></b>. Pesanan diproses setelah pembayaran dikonfirmasi.</p>
    <?php else: ?>
        <?php if ($o['metode'] == 'QRIS'): ?>
        <div class="qris">QRIS</div>
        <p style="text-align:center">Scan QRIS lalu bayar <b><?= $rp($o['total']) ?></b></p>
        <?php else: ?>
        <p>Transfer <b><?= $rp($o['total']) ?></b> ke <b>BCA 1234567890 a.n. Hj. Mina</b></p>
        <?php endif; ?>
        <form method="post"><button name="sudah">Saya Sudah Bayar</button></form>
    <?php endif; ?>
</div>
<?php elseif ($o['status_bayar'] == 'Menunggu Verifikasi'): ?>
<div class="ok">Pembayaran Anda sedang diverifikasi admin.</div>
<?php endif; ?>
<a href="index.php">← Pesan menu lain</a>
</main>
</body>
</html>

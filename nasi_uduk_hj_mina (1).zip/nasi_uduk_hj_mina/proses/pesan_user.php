<?php
include_once __DIR__."/../koneksi.php";

$keranjang = json_decode($_POST['keranjang'] ?? '', true);
$metode = in_array($_POST['metode'] ?? '', ['Tunai', 'QRIS', 'Transfer']) ? $_POST['metode'] : 'Tunai';
$catatan = substr($_POST['catatan'] ?? '', 0, 200);
$nama_pemesan = trim(substr($_POST['nama_pemesan'] ?? 'Tamu', 0, 100)) ?: 'Tamu';

$items = [];
$total = 0;
foreach ((array)$keranjang as $id => $jumlah) {
    $id = (int)$id;
    $jumlah = (int)$jumlah;
    if ($jumlah < 1) continue;
    $m = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga FROM menu WHERE id=$id AND status='Tersedia'"));
    if (!$m) continue;
    $items[] = [$id, $jumlah, (int)$m['harga']];
    $total += $jumlah * (int)$m['harga'];
}
if (!$items) {
    die("Keranjang kosong atau menu tidak tersedia. <a href='../user/index.php'>Kembali</a>");
}

$kode = "ORD-" . date("ymdHis") . rand(10, 99);
mysqli_begin_transaction($conn);
$stmt = mysqli_prepare($conn, "INSERT INTO pesanan(kode,nama_pemesan,total,metode,catatan) VALUES(?,?,?,?,?)");
mysqli_stmt_bind_param($stmt, "ssiss", $kode, $nama_pemesan, $total, $metode, $catatan);
mysqli_stmt_execute($stmt);
$pesanan_id = mysqli_insert_id($conn);

foreach ($items as [$menu_id, $jumlah, $harga]) {
    mysqli_query($conn, "INSERT INTO pesanan_detail(pesanan_id,menu_id,jumlah,harga) VALUES($pesanan_id,$menu_id,$jumlah,$harga)");
}
mysqli_commit($conn);

header("Location: ../user/bayar.php?id=$pesanan_id&kode=" . urlencode($kode) . "&baru=1");

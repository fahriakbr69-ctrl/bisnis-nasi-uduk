<?php
require_once "auth.php";
include_once "koneksi.php";
if (!empty($_SESSION['admin'])) { header("Location: index.php"); exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE username=?");
    mysqli_stmt_bind_param($stmt, "s", $_POST['username']);
    mysqli_stmt_execute($stmt);
    $u = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($u && password_verify($_POST['password'], $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin'] = ['id' => $u['id'], 'nama' => $u['nama']];
        header("Location: index.php");
        exit;
    }
    $err = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin - Nasi Uduk Hj. Mina</title>
<link rel="stylesheet" href="assets/user.css">
</head>
<body>
<div class="auth"><div class="box">
    <h2 style="text-align:center;color:#7c2d12;margin:0">Nasi Uduk Hj. Mina</h2>
    <p style="text-align:center;color:#777">Login Admin / Kasir</p>
    <?php if ($err): ?><div class="err"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
        <label>Username</label>
        <input name="username" required autofocus>
        <label>Password</label>
        <input type="password" name="password" required>
        <button style="width:100%">Masuk</button>
    </form>
    <p style="text-align:center"><a href="user/index.php">← Kembali ke menu pelanggan</a></p>
</div></div>
</body>
</html>
